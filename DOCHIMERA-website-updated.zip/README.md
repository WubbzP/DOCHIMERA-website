# dochimera.com

The source for [dochimera.com](https://dochimera.com), the official website of DOCHIMERA, a vocal synth group made up of two sets of twins. DOCHIMERA releases its music through WubbzP Music.

## What's on the site

- **Home** (`/`): the members, the featured release (*DOCHIMERA, Vol. 1*), a visitor counter, the latest news and a clover you can poke.
- **About** (`/about/`): the group's bio, quick facts and a timeline.
- **Members** (`/members/`): every member and voicebank, each with their own section.
- **Music** (`/music/`): the discography, with editions, release dates and track lists.
- **Contact** (`/contact/`): e-mail details and where else to find the group.

## Design

The site is built on the same layout and code as [wubbzp.com](https://wubbzp.com) (a framed stage, a ribbon menu, a sidebar and panels), restyled around the DOCHIMERA clover logo. Its mint, pink and peach leaves set the colours, and small clovers appear in the backgrounds, menu bullets and panel corners. All the artwork is made in CSS, apart from the logo, member icons and cover art.

## How it's built

dochimera.com is a plain static website (HTML, CSS and a small amount of JavaScript) with no build step or framework. It's hosted on GitHub Pages using the custom domain in `CNAME`.

| Path | What it is |
| --- | --- |
| `index.html` | Home page |
| `about/`, `members/`, `music/`, `contact/` | The other pages |
| `404.html` | The "page not found" page |
| `assets/css/style.css` | Styles shared by every page |
| `assets/js/site.js` | Scripts shared by every page: the Members and Music pickers, the clover, the visitor counter and the copy button |
| `assets/images/clover.png` | The clover logo with a transparent background |
| `assets/images/members/` | Member and voicebank icons |
| `assets/images/covers/` | Album cover art |

All images are stored in this repository, so the site doesn't depend on any outside image hosts. Each page loads the stylesheet and script with a `?v=` version tag, so visitors get the latest version as soon as it changes.

## Outside services

- [Font Awesome](https://fontawesome.com) for icons.
- [Google Fonts](https://fonts.google.com) for Fredoka, Nunito and Mochiy Pop One (used for Japanese text).
- [Abacus](https://abacus.jasoncameron.dev) for the visitor counter.

## Credits

Site content and music by DOCHIMERA. Arista and Polaris artwork as credited on the Members page. All covered songs and other trademarks are the property of their respective owners.
